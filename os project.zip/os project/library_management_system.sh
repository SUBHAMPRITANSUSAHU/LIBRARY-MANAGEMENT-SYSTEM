#!/bin/bash

# Define the library collection file
library_file="library.txt"

# Function to add a book to the library
add_book() {
  echo "Enter the book details:"
  read -p "Title: " title
  read -p "Author: " author
  read -p "ISBN: " isbn
  read -p "Publisher: " publisher
  read -p "Year: " year

  # Check if the book already exists in the library
  if grep -q "^$isbn|" $library_file; then
    echo "Error: Book with ISBN $isbn already exists in the library"
    return
  fi

  # Create the book record and append it to the library collection file
  book_record="$title|$author|$isbn|$publisher|$year"
  echo $book_record >> $library_file

  echo "Book added successfully!"
}

# Function to remove a book from the library
remove_book() {
  echo "Enter the ISBN of the book to be removed:"
  read isbn

  # Check if the book exists in the library
  if ! grep -q "^$isbn|" $library_file; then
    echo "Error: Book with ISBN $isbn does not exist in the library"
    return
  fi

  # Remove the book record from the library collection file
  sed -i "/^$isbn|/d" $library_file

  echo "Book removed successfully!"
}

# Function to search for books in the library
search_books() {
  echo "Enter the search keyword:"
  read keyword

  # Search for books that match the keyword in the title, author, or publisher fields
  results=$(grep -i "$keyword" $library_file)

  if [ -z "$results" ]; then
    echo "No books found matching '$keyword'"
  else
    echo "Search results for '$keyword':"
    echo "Title | Author | ISBN | Publisher | Year"
    echo "----------------------------------------"
    echo "$results"
  fi
}

# Function to display all books in the library
display_books() {
  echo "All books in the library:"
  echo "Title | Author | ISBN | Publisher | Year"
  echo "----------------------------------------"

  # Read each book record from the library collection file and display it
  while IFS="|" read -r title author isbn publisher year; do
    echo "$title | $author | $isbn | $publisher | $year"
  done < $library_file
}

# Display the menu of options
while true; do
  echo "Please select an option:"
  echo "1. Add a book"
  echo "2. Remove a book"
  echo "3. Search for books"
  echo "4. Display all books"
  echo "5. Exit"
  read choice

  case $choice in
    1)
      add_book
      ;;
    2)
      remove_book
      ;;
    3)
      search_books
      ;;
    4)
      display_books
      ;;
    5)
      echo "Goodbye!"
      exit 0
      ;;
    *)
      echo "Invalid option selected"
      ;;
      esac
      done